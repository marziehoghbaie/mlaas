from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Fieldset, ButtonHolder, Submit, HTML, Div
from crispy_forms.bootstrap import TabHolder, Tab, Field
from mlaas import models
from django.forms import formset_factory, modelformset_factory

kernel_Select = (
    ('linear', 'linear'),
    ('poly', 'poly'),
    ('rbf', 'rbf'),
    ('sigmoid', 'sigmoid'),
    ('precomputed', 'precomputed'),
)

TTS_Select = (
    ('0.1', '0.1'),
    ('0.2', '0.2'),
    ('0.3', '0.3'),
    ('0.4', '0.4'),
    ('0.5', '0.5'),
)

Sklearn_DataSets = (
    ('iris', 'iris'),
)
k_Select = (
    # (value, presentation)
    ('1', '1'),
    ('3', '3'),
    ('5', '5'),
    ('7', '7'),
    ('9', '9'),
    ('11', '11'),
    ('13', '13'),
    ('15', '15'),
)

weights_Select = (
    ('uniform', 'uniform'),
    ('distance', 'distance'),
)
algorithm_Select = (
    ('auto', 'auto'),
    ('ball_tree', 'ball_tree'),
    ('kd_tree', 'brute'),
    ('brute', 'brute'),
)

Reg_Cat_Binary = (
    ('Regression', 'Regression'),
    ('Categorical', 'Categorical'),
    # ('Binary','Binary'),
)

Regression_classification = (
    ('kNN_regression', 'kNN regression'),
    ('Naive bayes', (
        ('GaussianNB', 'GaussianNB'),
        ('BernoulliNB', 'BernoulliNB'),
        ('MultinomialNB', 'MultinomialNB')
    )
     ),
    ('SVR', 'Support Vector Machine'),
)

Categorical_classification = (
    ('kNN_categorical', 'kNN categorical'),
    ('Naive bayes', (
        ('GaussianNB', 'GaussianNB'),
        ('BernoulliNB', 'BernoulliNB'),
        ('MultinomialNB', 'MultinomialNB')
    )
     ),
    ('SVC', 'SVC'),
)



class DataSet_Model_Selection_Form(forms.Form):
    UserDataSet = forms.ModelChoiceField(queryset=None,
                                         label="Select A DataSet",
                                         widget=forms.Select)

    TargetType = forms.ChoiceField(required=True,
                                   widget=forms.Select,
                                   choices=Reg_Cat_Binary,
                                   label='Target Type')

    Categorical_Model_Type = forms.ChoiceField(required=False,
                                               widget=forms.Select,
                                               choices=Categorical_classification,
                                               initial='kNN_categorical',
                                               label='Classification Algorithm')

    Regression_Model_Type = forms.ChoiceField(required=False,
                                              widget=forms.Select,
                                              choices=Regression_classification,
                                              initial='kNN_regression',
                                              label='Regression Algorithm')

    def __init__(self, *args, **kwargs):
        super(DataSet_Model_Selection_Form, self).__init__(*args, **kwargs)
        # self.helper = FormHelper()
        # self.helper.layout = Fieldset(
        #     'form',
        #     'UserDataSet',
        #     'Classification_Model_Type',
        #     Submit('add', 'Add')
        # )

        self.fields['UserDataSet'].queryset = models.DataSet.objects.all()


class kNNCat_Form(forms.Form):
    n_neighbors = forms.ChoiceField(required=False, widget=forms.Select, choices=k_Select, initial=5)
    Test_Train_Split = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select, initial=0.2)
    weights = forms.ChoiceField(required=False, widget=forms.Select, choices=weights_Select, initial='uniform')
    algorithm = forms.ChoiceField(required=False, widget=forms.Select, choices=algorithm_Select, initial='auto')
    leaf_size = forms.IntegerField(initial=30, required=False)
    p = forms.IntegerField(initial=2, required=False)
    metric = forms.CharField(required=False, initial='cosine')
    n_jobs = forms.IntegerField(initial=1, required=False)


class kNNReg_Form(forms.Form):
    n_neighbors = forms.ChoiceField(required=False, widget=forms.Select, choices=k_Select, initial=5)
    Test_Train_Split = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select, initial=0.2)
    weights = forms.ChoiceField(required=False, widget=forms.Select, choices=weights_Select, initial='uniform')
    algorithm = forms.ChoiceField(required=False, widget=forms.Select, choices=algorithm_Select, initial='auto')
    leaf_size = forms.IntegerField(initial=30, required=False)
    p = forms.IntegerField(initial=2, required=False)
    metric = forms.CharField(required=False, initial='cosine')
    n_jobs = forms.IntegerField(initial=1, required=False)


class GaussianNB_form(forms.Form):
    Test_Train_Split = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select, initial=0.2)


class MultinomialNB_form(forms.Form):
    alpha = forms.FloatField(required=False, initial=1)
    fit_prior = forms.BooleanField(required=False, initial=True)
    Test_Train_Split = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select, initial=0.2)


class BernoulliNB_form(forms.Form):
    binarize = forms.FloatField(required=False, initial=0.0)
    alpha = forms.FloatField(required=False, initial=1)
    fit_prior = forms.BooleanField(required=False, initial=True)
    Test_Train_Split = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select, initial=0.2)


class SVC_form(forms.Form):
    decision_function_shape_Select = (
        ('ovo', 'ovo'),
        ('ovr', 'ovr'),
    )
    C = forms.FloatField(required=False, initial=1)
    kernel = forms.ChoiceField(required=False,
                               widget=forms.Select,
                               choices=kernel_Select,
                               initial='rbf')
    cache_size = forms.FloatField(required=False, initial=200)
    coef0 = forms.FloatField(required=False, initial=0)
    decision_function_shape = forms.ChoiceField(required=False,
                                                widget=forms.Select,
                                                choices=decision_function_shape_Select,
                                                initial='ovr')
    degree = forms.IntegerField(initial=3, required=False)
    # gamma =forms.FloatField(required=False, initial=1)
    max_iter = forms.IntegerField(required=False, initial=-1)
    probability = forms.BooleanField(required=False, initial=False)
    # random_state =
    shrinking = forms.BooleanField(required=False, initial=True)
    tol = forms.FloatField(required=False, initial=1e-3)
    verbose = forms.BooleanField(required=False, initial=False)
    Test_Train_Split = forms.ChoiceField(required=False,
                                         widget=forms.Select,
                                         choices=TTS_Select,
                                         initial=0.2)


class SVR_form(forms.Form):
    kernel = forms.ChoiceField(required=False,
                               widget=forms.Select,
                               choices=kernel_Select,
                               initial='rbf')
    degree = forms.IntegerField(initial=3, required=False)
    # gamma =
    coef0 = forms.FloatField(required=False, initial=0)
    tol = forms.FloatField(required=False, initial=1e-3)
    C = forms.FloatField(required=False, initial=1)
    epsilon = forms.FloatField(required=False, initial=1.0)
    shrinking = forms.BooleanField(required=False, initial=True)
    cache_size = forms.FloatField(required=False, initial=200)
    verbose = forms.BooleanField(required=False, initial=False)
    max_iter = forms.IntegerField(required=False, initial=-1)
    Test_Train_Split = forms.ChoiceField(required=False,
                                         widget=forms.Select,
                                         choices=TTS_Select,
                                         initial=0.2)


class ExampleForm(forms.Form):
    like_website = forms.TypedChoiceField(
        label="Do you like this website?",
        choices=((1, "Yes"), (0, "No")),
        coerce=lambda x: bool(int(x)),
        widget=forms.RadioSelect,
        initial='1',
        required=False,
    )

    favorite_food = forms.CharField(
        label="What is your favorite food?",
        max_length=80,
        required=False,
    )

    favorite_color = forms.CharField(
        label="What is your favorite color?",
        max_length=80,
        required=False,
    )

    favorite_number = forms.IntegerField(
        label="Favorite number",
        required=False,
    )

    notes = forms.CharField(
        label="Additional notes or feedback",
        required=False,
    )

    def __init__(self, *args, **kwargs):
        super(ExampleForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(

            TabHolder(
                Tab('First Tab',
                    'like_website',
                    Div('favorite_number')
                    ),
                Tab('Second Tab',
                    Field('notes', css_class="extra"))
            ),
            Submit('add', 'Add')

        )


class f1(forms.Form):
    s = forms.ChoiceField(required=False, widget=forms.Select, choices=TTS_Select)


class f2(forms.Form):
    b = forms.IntegerField(initial=10)

from django.urls import path, include
from django.conf.urls import url
from django.conf import settings
from . import views

urlpatterns = [
    path('ModelSelection/', views.MLClassification, name='ModelSelection'),
    path('test', views.t),
    path('kNN_regression', views.kNN_Model_regression, name='kNN_regression'),
    path('kNN_categorical', views.kNN_Model_categorical, name='kNN_categorical'),
    path('GaussianNB', views.GaussianNB_model, name='GaussianNB'),
    path('BernoulliNB', views.BernoulliNB_model, name='BernoulliNB'),
    path('MultinomialNB', views.MultinomialNB_model, name='MultinomialNB'),
    path('SVC', views.SVC_model, name='SVC'),
    path('SVR', views.SVR_model, name='SVR'),
]


